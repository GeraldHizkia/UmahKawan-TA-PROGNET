<?php
include "config.php";

include "functions.php"

?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>UmahKawan</title>

  <link rel="stylesheet" href="./css/bootstrap.min.css" />
  <link rel="stylesheet" href="./css/animate.css" />

  <link rel="stylesheet" href="./css/owl.carousel.min.css" />
  <link rel="stylesheet" href="./css/owl.theme.default.min.css" />
  <link rel="stylesheet" href="./css/magnific-popup.css" />

  <link rel="stylesheet" href="./css/aos.css" />

  <link rel="stylesheet" href="./css/ionicons.min.css" />

  <link rel="stylesheet" href="./css/flaticon.css" />
  <link rel="stylesheet" href="./css/icomoon.css" />
  <link rel="stylesheet" href="./css/style.css" />
  <link rel="shortcut icon" href="./img/favicon.ico" type="image/x-icon">
  <style>
    /* Map helpers with fixed height */
    .map-gap {
      margin: 30px 0;
    }

    .map-responsive {
      position: relative;
      height: 400px;
      overflow: hidden;
    }

    .map-responsive iframe {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      border: 0;
    }
  </style>
</head>

<body>
  <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
    <div class="container">
      <a class="navbar-brand" href="index.html">Umah<small>Kawan</small></a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav"
        aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="oi oi-menu"></span> Menu
      </button>
      <div class="collapse navbar-collapse" id="ftco-nav">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item active">
            <a href="index.html" class="nav-link">Home</a>
          </li>
          <li class="nav-item">
            <a href="menu.html" class="nav-link">Menu</a>
          </li>
          <li class="nav-item">
            <a href="services.html" class="nav-link">Review</a>
          </li>

          <li class="nav-item">
            <a href="about.html" class="nav-link">About</a>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="./cart.html" id="dropdown04" data-toggle="dropdown"
              aria-haspopup="true" aria-expanded="false">Shop</a>
            <div class="dropdown-menu" aria-labelledby="dropdown04">
              <a class="dropdown-item" href="shop.html">Shop</a>
              <a class="dropdown-item" href="./produk.html">Single Product</a>
              <a class="dropdown-item" href="checkout.html">Checkout</a>
            </div>
          </li>
          <li class="nav-item">
            <a href="contact.html" class="nav-link">Contact</a>
          </li>
          <li class="nav-item cart">
            <a href="cart.html" class="nav-link">
              <span class="icon icon-shopping_cart"></span>

            </a>
          </li>
        </ul>
      </div>
    </div>
  </nav>

  <!-- END nav -->

  <section class="home-slider owl-carousel">
    <div class="slider-item" style="background-image: url(./img/bgrujak.png)">
      <div class="overlay"></div>
      <div class="container">
        <div class="row slider-text justify-content-center align-items-center" data-scrollax-parent="true">
          <div class="col-md-8 col-sm-12 text-center ftco-animate">
            <span class="subheading">Welcome</span>
            <h1 class="mb-4">The Best Rujak Testing Experience</h1>
            <ion-icon name="cart"></ion-icon>
            <p class="mb-4 mb-md-5">
              Taste the ultimate flavor adventure! Our Rujak is crafted from handpicked, fresh fruits and an unmatched signature sweet and spicy dressing. Don't just look—add it to your cart and experience the difference!
            </p>
            <p>
              <!-- <a href="#" class="btn btn-primary p-3 px-xl-4 py-xl-3"
                  >Order Now</a
                > -->
              <a href="./menu.html" class="btn btn-white btn-outline-white p-3 px-xl-4 py-xl-3">View Menu</a>
            </p>
          </div>
        </div>
      </div>
    </div>

    <div class="slider-item" style="background-image: url(./img/bg-rujak2.png)">
      <div class="overlay"></div>
      <div class="container">
        <div class="row slider-text justify-content-center align-items-center" data-scrollax-parent="true">
          <div class="col-md-8 col-sm-12 text-center ftco-animate">
            <span class="subheading">Wellcome</span>
            <h1 class="mb-4">Authentic Rujak Flavors, Soothing Ambience</h1>
            <p class="mb-4 mb-md-5">
              The perfect blend of authentic Balinese sweet and spicy flavors with a comfortable, natural setting. It's
              time to treat yourself!
            </p>
            <p>
              <a href="./menu.html" class="btn btn-white btn-outline-white p-3 px-xl-4 py-xl-3">VIEW MENU</a>
            </p>
          </div>
        </div>
      </div>
    </div>

    <div class="slider-item" style="background-image: url(img/bg_packaging.png)">
      <div class="overlay"></div>
      <div class="container">
        <div class="row slider-text justify-content-center align-items-center" data-scrollax-parent="true">
          <div class="col-md-8 col-sm-12 text-center ftco-animate">
            <span class="subheading">Wellcome</span>
            <h1 class="mb-4">Savory, Warm, and Ready to Eat Anywhere</h1>
            <p class="mb-4 mb-md-5">
              Tipat Cantok and Plecing with creamy peanut sauce, served warm in secure and hygienic packaging. Order
              now, enjoy soon!
            </p>
            <p>
              <a href="./menu.html" class="btn btn-white btn-outline-white p-3 px-xl-4 py-xl-3">VIEW MENU</a>
            </p>
          </div>
        </div>
      </div>
    </div>
  </section>

  <section class="ftco-intro">
    <div class="container-wrap">
      <div class="wrap d-md-flex align-items-xl-end">
        <div class="info">
          <div class="row no-gutters">
            <div class="col-md-4 d-flex ftco-animate">
              <div class="icon"><span class="icon-phone"></span></div>
              <div class="text">
                <h3>+62 8953-3818-1468</h3>
                <p>
                  Authentic Indonesian Fruit Salad, Made with Love. Original
                  Flavors, Cozy Vibes. Every bite is a story, every blend is a
                  moment of warmth.
                </p>
              </div>
            </div>
            <div class="col-md-4 d-flex ftco-animate">
              <div class="icon"><span class="icon-my_location"></span></div>
              <div class="text">
                <h3>Jl. P. Bungin I No.14</h3>
                <p>Pedungan, Denpasar Selatan, Kota Denpasar, Bali</p>
              </div>
            </div>
            <div class="col-md-4 d-flex ftco-animate">
              <div class="icon"><span class="icon-clock-o"></span></div>
              <div class="text">
                <h3>Open Everyday</h3>
                <p>12:00am - 18:00pm</p>
              </div>
            </div>
          </div>
        </div>
        <div class="book p-4">
          <h3>Order Now</h3>
          <form id="orderForm" class="appointment-form" onsubmit="return handleWhatsAppOrder(event)">
            <div class="d-md-flex">
              <div class="form-group">
                <input type="text" class="form-control" id="firstName" placeholder="First Name" required />
              </div>
              <div class="form-group ml-md-4">
                <input type="text" class="form-control" id="lastName" placeholder="Last Name" required />
              </div>
            </div>
            <div class="d-md-flex">
              <div class="form-group">
                <input type="text" class="form-control" id="address" placeholder="Alamat" required />
              </div>
            </div>
            <div class="d-md-flex">
              <div class="form-group">
                <textarea id="orderMessage" cols="30" rows="2" class="form-control" placeholder="Order" required></textarea>
              </div>
              <div class="form-group ml-md-4">
                <button type="submit" class="btn btn-white py-3 px-4">Order via WhatsApp</button>
              </div>
            </div>
          </form>
          <script>
            function handleWhatsAppOrder(event) {
              event.preventDefault();
              
              // Get form values
              const firstName = document.getElementById('firstName').value;
              const lastName = document.getElementById('lastName').value;
              const address = document.getElementById('address').value;
              const orderMessage = document.getElementById('orderMessage').value;
              
              // Format the message
              const message = `*New Order from ${firstName} ${lastName}*\n\n` +
                            `📍 Alamat: ${address}\n\n` +
                            `🛒 Pesanan:\n${orderMessage}`;
              
              // WhatsApp phone number (Indonesia format)
              const phone = '62895338181468';  // Your WhatsApp number without '+' or leading 0
              
              // Encode the message for URL
              const encodedMessage = encodeURIComponent(message);
              
              // Build the WhatsApp URL
              const whatsappURL = `https://wa.me/${phone}?text=${encodedMessage}`;
              
              // Open WhatsApp in a new tab
              window.open(whatsappURL, '_blank');
              
              return false;
            }
          </script>
        </div>
      </div>
    </div>
  </section>

  

  <section class="ftco-about d-md-flex">
    <div class="one-half img" style="background-image: url(./img/warung\ rujak.png)"></div>
    <div class="one-half ftco-animate">
      <div class="overlap">
        <div class="heading-section ftco-animate">
          <span class="subheading">Discover</span>
          <h2 class="mb-4">Our Story</h2>
        </div>
        <div>
          <p>
            On its journey, Umah Kawan found its heart in the small streets of
            Pedungan. What began as a simple local stall soon became a
            gathering place for friends, laughter, and the unmistakable flavor
            of Bali. Every bowl, every serving, carries the warmth of
            community and the spirit of home. The people came, one by one,
            drawn by the aroma and the smiles behind the counter. They shared
            stories, memories, and countless moments over plates of rujak and
            tipat cantok. Word spread across the island, and soon Umah Kawan
            was no longer just a name — it was an experience loved by many.
            Today, with more than 2,000 five-star reviews, Umah Kawan
            continues to serve not only food, but friendship in every bite.
          </p>
        </div>
      </div>
    </div>
  </section>

  <section class="ftco-section ftco-services">
    <div class="container">
      <div class="row">
        <div class="col-md-4 ftco-animate">
          <div class="media d-block text-center block-6 services">
            <div class="icon d-flex justify-content-center align-items-center mb-5">
              <span class="flaticon-choices"></span>
            </div>
            <div class="media-body">
              <h3 class="heading">Easy to Order</h3>
              <p>
                Whether you’re craving something sweet, spicy, or tangy, Umah Kawan makes it easy to order your favorite
                rujak in just a few clicks.
              </p>
            </div>
          </div>
        </div>
        <div class="col-md-4 ftco-animate">
          <div class="media d-block text-center block-6 services">
            <div class="icon d-flex justify-content-center align-items-center mb-5">
              <span class="flaticon-delivery-truck"></span>
            </div>
            <div class="media-body">
              <h3 class="heading">Fastest Delivery</h3>
              <p>
                Our fresh rujak is delivered quickly to your door. We make sure every bite stays delicious and full of
                flavor.
              </p>
            </div>
          </div>
        </div>
        <div class="col-md-4 ftco-animate">
          <div class="media d-block text-center block-6 services">
            <div class="icon d-flex justify-content-center align-items-center mb-5">
              <img src="./fonts/flaticon/icon-fruit.png" width="50%">
            </div>
            <div class="media-body">
              <h3 class="heading">Fresh Ingredients</h3>
              <p>
                Made from handpicked tropical fruits and authentic Balinese spices, every serving is crafted with care
                to bring you the perfect balance of sweet, spicy, and tangy flavors.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <section class="ftco-section">
    <div class="container">
      <div class="row align-items-center">
        <div class="col-md-6 pr-md-5">
          <div class="heading-section text-md-right ftco-animate">
            <span class="subheading">Discover</span>
            <h2 class="mb-4">Our Menu</h2>
            <p class="mb-4">
              We bring you a menu bursting with flavor, using only the freshest fruits, crispest vegetables, and
              signature sauces handcrafted daily. Get ready for a delicious explosion of sweet, sour, and spicy.
            </p>
            <p>
              <a href="./menu.html" class="btn btn-primary btn-outline-primary px-4 py-3">View Full Menu</a>
            </p>
          </div>
        </div>
        <div class="col-md-6">
          <div class="row">
            <div class="col-md-6">
              <div class="menu-entry">
                <a href="#" class="img" style="background-image: url(./img/syrtlrcantok.jpg)"></a>
              </div>
            </div>
            <div class="col-md-6">
              <div class="menu-entry mt-lg-4">
                <a href="#" class="img" style="background-image: url(./img/bg-rujak2.png)"></a>
              </div>
            </div>
            <div class="col-md-6">
              <div class="menu-entry">
                <a href="#" class="img" style="background-image: url(./img/esdaluman2.png)"></a>
              </div>
            </div>
            <div class="col-md-6">
              <div class="menu-entry mt-lg-4">
                <a href="#" class="img" style="background-image: url(./img/tipat_cantok.png)"></a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <section class="ftco-counter ftco-bg-dark img" id="section-counter" style="background-image: url(./img/gambar_1.jpg)"
    data-stellar-background-ratio="0.5">
    <div class="overlay"></div>
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-md-10">
          <div class="row">
            <div class="col-md-6 col-lg-3 d-flex justify-content-center counter-wrap ftco-animate">
              <div class="block-18 text-center">
                <div class="text">
                  <div class="icon d-flex justify-content-center align-items-center">
                    <img src="./fonts/flaticon/icon-branch.png" width="50%" style="object-fit: contain;"
                      alt="Branch Icon">
                  </div>

                  <strong class="number" data-number="5">0</strong>
                  <span>Umah Kawan Branches</span>
                </div>
              </div>
            </div>
            <div class="col-md-6 col-lg-3 d-flex justify-content-center counter-wrap ftco-animate">
              <div class="block-18 text-center">
                <div class="text">
                  <div class="icon d-flex justify-content-center align-items-center">
                    <img src="./fonts/flaticon/icon-award.png" width="50%" style="object-fit: contain;"
                      alt="Awards Icon">
                  </div>
                  <strong class="number" data-number="20">0</strong>
                  <span>Number of Awards</span>
                </div>
              </div>
            </div>
            <div class="col-md-6 col-lg-3 d-flex justify-content-center counter-wrap ftco-animate">
              <div class="block-18 text-center">
                <div class="text">
                  <div class="icon d-flex justify-content-center align-items-center">
                    <img src="./fonts/flaticon/icon-cust.png" width="50%" style="object-fit: contain;"
                      alt="Customer Icon">
                  </div>
                  <strong class="number" data-number="2521">0</strong>
                  <span>Happy Customer</span>
                </div>
              </div>
            </div>
            <div class="col-md-6 col-lg-3 d-flex justify-content-center counter-wrap ftco-animate">
              <div class="block-18 text-center">
                <div class="text">
                  <div class="icon d-flex justify-content-center align-items-center">
                    <img src="./fonts/flaticon/icon-staf.png" width="50%" style="object-fit: contain;" alt="Staff Icon">
                  </div>
                  <strong class="number" data-number="100">0</strong>
                  <span>Staff</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <section class="ftco-section">
    <div class="container">
      <div class="row justify-content-center mb-5 pb-3">
        <div class="col-md-7 heading-section ftco-animate text-center">
          <span class="subheading">Discover</span>
          <h2 class="mb-4">Umah Kawan Best Sellers</h2>
          <p>
            These are the dishes everyone's talking about. Hand-picked favorites and timeless classics, perfected to be
            the freshest, spiciest, and most satisfying treats on the island. Taste what makes us the best.
          </p>
        </div>
      </div>
      <div class="row">
        <div class="col-md-3">
          <div class="menu-entry">
            <a href="#" class="img" style="background-image: url(./img/rujakuahpindangHD.png)"></a>
            <div class="text text-center pt-4">
              <h3><a href="./product-single.html">Rujak Kuah Pindang</a></h3>
              <p>
                Segar pedas gurih khas kuah pindang Bali.
              </p>
              <p class="price"><span>Rp8.000</span></p>
              <p>
                <a href="#" class="btn btn-primary btn-outline-primary">Add to Cart</a>
              </p>
            </div>
          </div>
        </div>
        <div class="col-md-3">
          <div class="menu-entry">
            <a href="#" class="img" style="background-image: url(./img/tipat_cantok2.png)"></a>
            <div class="text text-center pt-4">
              <h3><a href="#">Tipat Cantok</a></h3>
              <p>
                Lontong sayur khas Bali dengan bumbu kacang gurih.

              </p>
              <p class="price"><span>Rp10.000</span></p>
              <p>
                <a href="#" class="btn btn-primary btn-outline-primary">Add to Cart</a>
              </p>
            </div>
          </div>
        </div>
        <div class="col-md-3">
          <div class="menu-entry">
            <a href="#" class="img" style="background-image: url(./img/bulungboni.jpeg)"></a>
            <div class="text text-center pt-4">
              <h3><a href="#">Bulung Boni Cantok</a></h3>
              <p>
                Bulung boni disiram bumbu kacang gurih pedas.

              </p>
              <p class="price"><span>Rp14.000</span></p>
              <p>
                <a href="#" class="btn btn-primary btn-outline-primary">Add to Cart</a>
              </p>
            </div>
          </div>
        </div>
        <div class="col-md-3">
          <div class="menu-entry">
            <a href="#" class="img" style="background-image: url(./img/images.jpeg)"></a>
            <div class="text text-center pt-4">
              <h3><a href="#">Es Extra Joss Susu</a></h3>
              <p>
                Segarnya susu berpadu energi dari Extra Joss.
              </p>
              <p class="price"><span>Rp5.000</span></p>
              <p>
                <a href="#" class="btn btn-primary btn-outline-primary">Add to Cart</a>
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <section class="ftco-gallery">
    <div class="container-wrap">
      <div class="row no-gutters">
        <div class="col-md-3 ftco-animate">
          <a href="#" class="gallery img d-flex align-items-center" style="background-image: url(./img/restoran1.jpg)">
            <div class="icon mb-4 d-flex align-items-center justify-content-center">
              <span class="icon-search"></span>
            </div>
          </a>
        </div>
        <div class="col-md-3 ftco-animate">
          <a href="#" class="gallery img d-flex align-items-center" style="background-image: url(./img/restoran2.jpg)">
            <div class="icon mb-4 d-flex align-items-center justify-content-center">
              <span class="icon-search"></span>
            </div>
          </a>
        </div>
        <div class="col-md-3 ftco-animate">
          <a href="#" class="gallery img d-flex align-items-center" style="background-image: url(./img/gallery3.png)">
            <div class="icon mb-4 d-flex align-items-center justify-content-center">
              <span class="icon-search"></span>
            </div>
          </a>
        </div>
        <div class="col-md-3 ftco-animate">
          <a href="#" class="gallery img d-flex align-items-center" style="background-image: url(./img/gallery1.jpg)">
            <div class="icon mb-4 d-flex align-items-center justify-content-center">
              <span class="icon-search"></span>
            </div>
          </a>
        </div>
      </div>
    </div>
  </section>

  <section class="ftco-menu mb-5 pb-5">
    <div class="container">
      <div class="row justify-content-center mb-5">
        <div class="col-md-7 heading-section text-center ftco-animate">
          <span class="subheading">Discover</span>
          <h2 class="mb-4">Our Products</h2>
          <p>Feeling down? It’s time to grab our fresh rujak!.</p>
        </div>
      </div>
      <div class="row d-md-flex">
        <div class="col-lg-12 ftco-animate p-md-5">
          <div class="row">
            <div class="col-md-12 nav-link-wrap mb-5">
              <div class="nav ftco-animate nav-pills justify-content-center" id="v-pills-tab" role="tablist"
                aria-orientation="vertical">
                <a class="nav-link active" id="v-pills-1-tab" data-toggle="pill" href="#v-pills-1" role="tab"
                  aria-controls="v-pills-1" aria-selected="true">Rujak</a>
                <a class="nav-link" id="v-pills-2-tab" data-toggle="pill" href="#v-pills-2" role="tab"
                  aria-controls="v-pills-2" aria-selected="false">Tipat Cantok</a>
                <a class="nav-link" id="v-pills-3-tab" data-toggle="pill" href="#v-pills-3" role="tab"
                  aria-controls="v-pills-3" aria-selected="false">Plecing</a>
                <a class="nav-link" id="v-pills-4-tab" data-toggle="pill" href="#v-pills-4" role="tab"
                  aria-controls="v-pills-4" aria-selected="false">Drinks</a>
              </div>
            </div>
            <div class="col-md-12 d-flex align-items-center">
              <div class="tab-content ftco-animate" id="v-pills-tabContent">
                <div class="tab-pane fade show active" id="v-pills-1" role="tabpanel" aria-labelledby="v-pills-1-tab">
                  <div class="row">
                    <div class="col-md-4 text-center">
                      <div class="menu-wrap">
                        <a href="#" class="menu-img img mb-4" style="background-image: url(img/rjkkuahpindang.jpg)"></a>
                        <div class="text">
                          <h3><a href="#">Rujak Kuah Pindang</a></h3>
                          <p>Segar pedas gurih khas kuah pindang Bali.</p>
                          <p class="price"><span>Rp8.000</span></p>
                        </div>
                      </div>
                    </div>
                    <div class="col-md-4 text-center">
                      <div class="menu-wrap">
                        <a href="#" class="menu-img img mb-4" style="background-image: url(img/bg2.jpg)"></a>
                        <div class="text">
                          <h3><a href="#">Rujak Gula</a></h3>
                          <p>Manis asam segar dengan sambal gula merah.</p>
                          <p class="price"><span>Rp8.000</span></p>
                        </div>
                      </div>
                    </div>
                    <div class="col-md-4 text-center">
                      <div class="menu-wrap">
                        <a href="#" class="menu-img img mb-4" style="background-image: url(img/gambar_1.jpg);"></a>
                        <div class="text">
                          <h3><a href="#">Rujak Colek</a></h3>
                          <p>Buah segar dicolek sambal pedas manis.</p>
                          <p class="price"><span>Rp8.000</span></p>
                        </div>
                      </div>
                    </div>
                    <div class="col-md-4 text-center">
                      <div class="menu-wrap">
                        <a href="#" class="menu-img img mb-4" style="background-image: url(img/bulungboni.jpeg);"></a>
                        <div class="text">
                          <h3><a href="#">Rujak Bulung</a></h3>
                          <p>Rumput laut segar dengan kuah pindang khas.</p>
                          <p class="price"><span>Rp8.000</span></p>
                        </div>
                      </div>
                    </div>
                    <div class="col-md-4 text-center">
                      <div class="menu-wrap">
                        <a href="#" class="menu-img img mb-4" style="background-image: url(img/gambar5.jpg);"></a>
                        <div class="text">
                          <h3><a href="#">Rujak Kacang Manis</a></h3>
                          <p>Perpaduan buah segar dan bumbu kacang lembut.</p>
                          <p class="price"><span>Rp10.000</span></p>
                        </div>
                      </div>
                    </div>
                    <div class="col-md-4 text-center">
                      <div class="menu-wrap">
                        <a href="#" class="menu-img img mb-4" style="background-image: url(img/gambar_1.jpg);"></a>
                        <div class="text">
                          <h3><a href="#">Rujak Campur</a></h3>
                          <p>Kombinasi buah dan sayur segar dengan bumbu pilihan.</p>
                          <p class="price"><span>Rp9.000</span></p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="tab-pane fade" id="v-pills-2" role="tabpanel" aria-labelledby="v-pills-2-tab">
                  <div class="row">
                    <div class="col-md-4 text-center">
                      <div class="menu-wrap">
                        <a href="#" class="menu-img img mb-4" style="background-image: url(img/tipatcantok.jpg);"></a>
                        <div class="text">
                          <h3><a href="#">Tipat Cantok</a></h3>
                          <p>Lontong sayur khas Bali dengan bumbu kacang gurih.</p>
                          <p class="price"><span>Rp10.000</span></p>
                        </div>
                      </div>
                    </div>
                    <div class="col-md-4 text-center">
                      <div class="menu-wrap">
                        <a href="#" class="menu-img img mb-4"
                          style="background-image: url(img/cantok\ lengkap.jpg);"></a>
                        <div class="text">
                          <h3><a href="#">Tipat Cantok Telur Ayam</a></h3>
                          <p>Tipat cantok lezat dengan tambahan telur ayam.</p>
                          <p class="price"><span>Rp14.000</span></p>
                        </div>
                      </div>
                    </div>
                    <div class="col-md-4 text-center">
                      <div class="menu-wrap">
                        <a href="#" class="menu-img img mb-4" style="background-image: url(img/syrtlrcantok.jpg);"></a>
                        <div class="text">
                          <h3><a href="#">Sayur Cantok</a></h3>
                          <p>Sayur rebus segar disiram bumbu kacang khas.</p>
                          <p class="price"><span>Rp8.000</span></p>
                        </div>
                      </div>
                    </div>
                    <div class="col-md-4 text-center">
                      <div class="menu-wrap">
                        <a href="#" class="menu-img img mb-4" style="background-image: url(img/sayurcatok.jpg);"></a>
                        <div class="text">
                          <h3><a href="#">Sayur Cantok Telur Ayam</a></h3>
                          <p>Sayur cantok nikmat dengan telur ayam rebus.</p>
                          <p class="price"><span>Rp12.000</span></p>
                        </div>
                      </div>
                    </div>
                    <div class="col-md-4 text-center">
                      <div class="menu-wrap">
                        <a href="#" class="menu-img img mb-4"
                          style="background-image: url(img/cantok\ lengkap.jpg);"></a>
                        <div class="text">
                          <h3><a href="#">Sayur Cantok + Mie Goreng + Telur</a></h3>
                          <p>Paduan sayur, mie goreng, dan telur spesial.</p>
                          <p class="price"><span>Rp20.000</span></p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="tab-pane fade" id="v-pills-3" role="tabpanel" aria-labelledby="v-pills-3-tab">
                  <div class="row">
                    <div class="col-md-4 text-center">
                      <div class="menu-wrap">
                        <a href="#" class="menu-img img mb-4" style="background-image: url(img/syrplecing.jpg);"></a>
                        <div class="text">
                          <h3><a href="#">Sayur Plecing</a></h3>
                          <p>Sayur segar dengan sambal plecing khas Bali.</p>
                          <p class="price"><span>Rp8.000</span></p>
                        </div>
                      </div>
                    </div>
                    <div class="col-md-4 text-center">
                      <div class="menu-wrap">
                        <a href="#" class="menu-img img mb-4" style="background-image: url(img/plecinglur.jpg);"></a>
                        <div class="text">
                          <h3><a href="#">Sayur Plecing Telur Ayam</a></h3>
                          <p>Sayur plecing nikmat dengan tambahan telur ayam.</p>
                          <p class="price"><span>Rp12.000</span></p>
                        </div>
                      </div>
                    </div>
                    <div class="col-md-4 text-center">
                      <div class="menu-wrap">
                        <a href="#" class="menu-img img mb-4" style="background-image: url(img/bulungboni.jpeg);"></a>
                        <div class="text">
                          <h3><a href="#">Bulung Boni</a></h3>
                          <p>Rumput laut segar dengan kuah pindang pedas.</p>
                          <p class="price"><span>Rp8.000</span></p>
                        </div>
                      </div>
                    </div>
                    <div class="col-md-4 text-center">
                      <div class="menu-wrap">
                        <a href="#" class="menu-img img mb-4" style="background-image: url(img/bulungctk.jpeg);"></a>
                        <div class="text">
                          <h3><a href="#">Bulung Boni Cantok</a></h3>
                          <p>Bulung boni disiram bumbu kacang gurih pedas.</p>
                          <p class="price"><span>Rp14.000</span></p>
                        </div>
                      </div>
                    </div>
                    <div class="col-md-4 text-center">
                      <div class="menu-wrap">
                        <a href="#" class="menu-img img mb-4" style="background-image: url(img/tptplecing.jpg);"></a>
                        <div class="text">
                          <h3><a href="#">Tipat Plecing</a></h3>
                          <p>Lontong sayur plecing segar dengan sambal khas.</p>
                          <p class="price"><span>Rp10.000</span></p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="tab-pane fade" id="v-pills-4" role="tabpanel" aria-labelledby="v-pills-4-tab">
                  <div class="row">
                    <div class="col-md-4 text-center">
                      <div class="menu-wrap">
                        <a href="#" class="menu-img img mb-4" style="background-image: url(img/images.jpeg);"></a>
                        <div class="text">
                          <h3><a href="#">Es Extra Joss Susu</a></h3>
                          <p>Segarnya susu berpadu energi dari Extra Joss.</p>
                          <p class="price"><span>Rp5.000</span></p>
                        </div>
                      </div>
                    </div>
                    <div class="col-md-4 text-center">
                      <div class="menu-wrap">
                        <a href="#" class="menu-img img mb-4" style="background-image: url(img/esgulabali.jpg);"></a>
                        <div class="text">
                          <h3><a href="#">Es Gula</a></h3>
                          <p>Minuman manis sederhana yang menyegarkan hari Anda.</p>
                          <p class="price"><span>Rp5.000</span></p>
                        </div>
                      </div>
                    </div>
                    <div class="col-md-4 text-center">
                      <div class="menu-wrap">
                        <a href="#" class="menu-img img mb-4" style="background-image: url(img/esdaluman.jpg);"></a>
                        <div class="text">
                          <h3><a href="#">Es Daluman</a></h3>
                          <p>Cincau hijau khas Bali dengan santan dan gula.</p>
                          <p class="price"><span>Rp7.000</span></p>
                        </div>
                      </div>
                    </div>
                    <div class="col-md-4 text-center">
                      <div class="menu-wrap">
                        <a href="#" class="menu-img img mb-4" style="background-image: url(img/estape.jpeg);"></a>
                        <div class="text">
                          <h3><a href="#">Es Tape</a></h3>
                          <p>Manis asam segar dari tape ketan hijau.</p>
                          <p class="price"><span>Rp7.000</span></p>
                        </div>
                      </div>
                    </div>
                    <div class="col-md-4 text-center">
                      <div class="menu-wrap">
                        <a href="#" class="menu-img img mb-4" style="background-image: url(img/essusu.webp);"></a>
                        <div class="text">
                          <h3><a href="#">Es Susu</a></h3>
                          <p>Kesegaran susu dingin yang lembut dan manis.</p>
                          <p class="price"><span>Rp5.000</span></p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
  </section>
  <section class="ftco-section img" id="ftco-testimony" style="background-image: url(./img/rujakuahpindangHD.png)"
    data-stellar-background-ratio="0.5">
    <div class="overlay"></div>
    <div class="container">
      <div class="row justify-content-center mb-5">
        <div class="col-md-7 heading-section text-center ftco-animate">
          <span class="subheading">Testimony</span>
          <h2 class="mb-4">Customers Says</h2>
          <p>
            Your satisfaction is our most delicious ingredient. See and experience the real experiences of customers who
            have enjoyed the freshness of our Rujak and the warmth of our Balinese cuisine.
          </p>
        </div>
      </div>
    </div>
    <div class="container-wrap">
      <div class="row d-flex no-gutters">
        <div class="col-lg align-self-sm-end">
          <div class="testimony">
            <blockquote>
              <p>
                &ldquo;“Best rujak in Bali! The mix of sweet, spicy, and tangy flavors is just perfect. I come here
                almost every week — it never disappoints!”.&rdquo;
              </p>
            </blockquote>
            <div class="author d-flex mt-4">
              <div class="image mr-3 align-self-center">
                <img src="img/maudy_cust2.jpg" alt="" />
              </div>
              <div class="name align-self-center">
                Ayu Prameswari
                <span class="position">Illustrator Designer</span>
              </div>
            </div>
          </div>
        </div>
        <div class="col-lg align-self-sm-end">
          <div class="testimony overlay">
            <blockquote>
              <p>
                &ldquo;Umah Kawan is a hidden gem in Pedungan! Authentic Balinese flavors and warm hospitality — I’ll
                definitely come back next time I visit Bali.&rdquo;
              </p>
            </blockquote>
            <div class="author d-flex mt-4">
              <div class="image mr-3 align-self-center">
                <img src="img/jerome_cust1.jpg" alt="" />
              </div>
              <div class="name align-self-center">
                Jerome Polin
                <span class="position">Influencer</span>
              </div>
            </div>
          </div>
        </div>
        <div class="col-lg align-self-sm-end">
          <div class="testimony">
            <blockquote>
              <p>
                &ldquo;The rujak reminds me of my childhood! Spicy, fresh, and full of flavor. Plus, their delivery
                service is super fast and always on time. &rdquo;
              </p>
            </blockquote>
            <div class="author d-flex mt-4">
              <div class="image mr-3 align-self-center">
                <img src="img/gerald_cust3.jpg" alt="" />
              </div>
              <div class="name align-self-center">
                Gerald Hizkia
                <span class="position">Student</span>
              </div>
            </div>
          </div>
        </div>
        <div class="col-lg align-self-sm-end">
          <div class="testimony overlay">
            <blockquote>
              <p>
                &ldquo;I’ve tried many rujak places, but Umah Kawan has the best balance of taste and texture. You can
                really feel it’s made with love.&rdquo;
              </p>
            </blockquote>
            <div class="author d-flex mt-4">
              <div class="image mr-3 align-self-center">
                <img src="img/person_3.jpg" alt="" />
              </div>
              <div class="name align-self-center">
                Gusti Joko
                <span class="position">Actress</span>
              </div>
            </div>
          </div>
        </div>
        <div class="col-lg align-self-sm-end">
          <div class="testimony">
            <blockquote>
              <p>
                &ldquo;This place deserves all the five-star reviews! Every dish feels homemade and so good. The rujak
                bulung is a must-try for anyone visiting Bali. &rdquo;
              </p>
            </blockquote>
            <div class="author d-flex mt-4">
              <div class="image mr-3 align-self-center ">
                <img src="img/marulis_cus5.jpg" alt="" />
              </div>
              <div class="name align-self-center">
                Marulis
                <span class="position">Soldier</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <div class="map-gap">
    <div class="map-responsive">
      <iframe
        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2217.168506788972!2d115.20344982241302!3d-8.685001196221139!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2dd241ae1c626eef%3A0x2d7612833e0600fa!2sUmah%20Kawan%20Pedungan!5e1!3m2!1sid!2sid!4v1762246776584!5m2!1sid!2sid"
        allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
    </div>
  </div>

  <footer class="ftco-footer ftco-section img">
    <div class="overlay"></div>
    <div class="container">
      <div class="row mb-5">
        <div class="col-lg-3 col-md-6 mb-5 mb-md-5">
          <div class="ftco-footer-widget mb-4">
            <h2 class="ftco-heading-2">Toko Rujak Umah Kawan</h2>
            <p>
              Kami menyajikan rujak tradisional Bali dengan bahan-bahan segar
              dan sambal khas rumah. Nikmati paduan buah segar, bumbu
              pedas-manis, dan pelayanan ramah.
            </p>
            <ul class="ftco-footer-social list-unstyled float-md-left float-lft mt-3">
              <li class="ftco-animate">
                <a href="#"><span class="icon-twitter"></span></a>
              </li>
              <li class="ftco-animate">
                <a href="#"><span class="icon-facebook"></span></a>
              </li>
              <li class="ftco-animate">
                <a href="#"><span class="icon-instagram"></span></a>
              </li>
            </ul>
          </div>
        </div>
        <div class="col-lg-2 col-md-6 mb-5 mb-md-5">
          <div class="ftco-footer-widget mb-4 ml-md-4">
            <h2 class="ftco-heading-2">Services</h2>
            <ul class="list-unstyled">
              <li><a href="#" class="py-2 d-block">Cooked</a></li>
              <li><a href="#" class="py-2 d-block">Deliver</a></li>
              <li><a href="#" class="py-2 d-block">Quality Foods</a></li>
              <li><a href="#" class="py-2 d-block">Mixed</a></li>
            </ul>
          </div>
        </div>
        <div class="col-lg-3 col-md-6 mb-5 mb-md-5">
          <div class="ftco-footer-widget mb-4">
            <h2 class="ftco-heading-2">Have a Questions?</h2>
            <div class="block-23 mb-3">
              <ul>
                <li>
                  <span class="icon icon-map-marker"></span><span class="text">Jl. P. Bungin I No.14, Pedungan, Denpasar
                    Selatan, Bali
                    80222</span>
                </li>
                <li>
                  <a href="#"><span class="icon icon-phone"></span><span class="text">+62895-3381-81468</span></a>
                </li>
                <li>
                  <a href="#"><span class="icon icon-envelope"></span><span class="text">umahkawan@gmail.com</span></a>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-12 text-center">
          <p>

            Copyright &copy;
            <script>
              document.write(new Date().getFullYear());
            </script>
            All rights reserved | UmahKawan
          </p>
        </div>
      </div>
    </div>
  </footer>

  <!-- loader -->
  <div id="ftco-loader" class="show fullscreen">
    <svg class="circular" width="48px" height="48px">
      <circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee" />
      <circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10"
        stroke="#F96D00" />
    </svg>
  </div>

  <script src="./js/jquery.min.js"></script>
  <script src="./js/jquery-migrate-3.0.1.min.js"></script>
  <script src="./js/popper.min.js"></script>
  <script src="./js/bootstrap.min.js"></script>
  <script src="./js/jquery.easing.1.3.js"></script>
  <script src="./js/jquery.waypoints.min.js"></script>
  <script src="./js/jquery.stellar.min.js"></script>
  <script src="./js/owl.carousel.min.js"></script>
  <script src="./js/jquery.magnific-popup.min.js"></script>
  <script src="./js/aos.js"></script>
  <script src="./js/jquery.animateNumber.min.js"></script>
  <script src="./js/scrollax.min.js"></script>
  <script src="./js/main.js"></script>
</body>

</html>